<?php 

    header('Content-Type: application/json');

    require_once('../../config_model/question_db.php');

    if($_SERVER['REQUEST_METHOD'] != 'PUT') {
        $res = array(
            'code' => 4,
            'message' => 'This API only supports PUT'
        );

        http_response_code(405);

        die(json_encode($res));
    }

    $question = json_decode(file_get_contents('php://input'));

    if(is_null($question)) {
        $res = array(
            'code' => 2,
            'message' => 'Only JSON support'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if(!property_exists($question, 'title')
    || !property_exists($question, 'sentence_a')
    || !property_exists($question, 'sentence_b')
    || !property_exists($question, 'sentence_c')
    || !property_exists($question, 'sentence_d')
    || !property_exists($question, 'sentence_true')) {
        $res = array(
            'code' => 1,
            'message' => 'Lack of input information'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if(empty($question->title)
    || empty($question->sentence_a)
    || empty($question->sentence_b)
    || empty($question->sentence_c)
    || empty($question->sentence_d)
    || empty($question->sentence_true)) {
        $res = array(
            'code' => 1,
            'message' => 'Invalid information'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if(!isset($_GET['id'])) {
        $res = array(
            'code' => 1,
            'message' => 'Missing question id'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    $id = $_GET['id'];

    $id = intval($id);

    if($id === 0) {
        $res = array(
            'code' => 1,
            'message' => 'Invalid question id'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if($id < 1 || $id > 1000) {
        $res = array(
            'code' => 1,
            'message' => 'Question id is out of range'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    $title = $question->title;
    $sentence_a = $question->sentence_a;
    $sentence_b = $question->sentence_b;
    $sentence_c = $question->sentence_c;
    $sentence_d = $question->sentence_d;
    $sentence_true = $question->sentence_true;

    $result = update_question($id, $title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true);

    if(!$result) {
        $res = array(
            'code' => 3,
            'message' => 'Question id does not exist'
        );

        die(json_encode($res));
    }
    else {
        $res = array(   
            'code' => 0,
            'message' => 'Update question success',
            'question' => $question
        );

        die(json_encode($res));
    }
?>