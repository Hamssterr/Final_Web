<?php 

header('Content-Type: application/json');

require_once('../../config_model/question_db.php');

    if($_SERVER['REQUEST_METHOD'] != 'POST') {
        $res = array(
            'code' => 4,
            'message' => 'This API only supports POST'
        );

        http_response_code(405);

        die(json_encode($res));
    }

    $question = json_decode(file_get_contents('php://input'));

    if(is_null($question)) {
        $res = array(
            'code' => 2,
            'message' => 'Only JSON support'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if(!property_exists($question, 'title')
    || !property_exists($question, 'sentence_a')
    || !property_exists($question, 'sentence_b')
    || !property_exists($question, 'sentence_c')
    || !property_exists($question, 'sentence_d')
    || !property_exists($question, 'sentence_true')) {
        $res = array(
            'code' => 1,
            'message' => 'Lack of input information'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if(empty($question->title)
    || empty($question->sentence_a)
    || empty($question->sentence_b)
    || empty($question->sentence_c)
    || empty($question->sentence_d)
    || empty($question->sentence_true)) {
        $res = array(
            'code' => 1,
            'message' => 'Invalid information'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    $title = $question->title;
    $sentence_a = $question->sentence_a;
    $sentence_b = $question->sentence_b;
    $sentence_c = $question->sentence_c;
    $sentence_d = $question->sentence_d;
    $sentence_true = $question->sentence_true;

    $id = add_question($title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true);

    if($id === null) {
        $res = array(
            'code' => 3,
            'message' => 'Can not execute command'
        );

        die(json_encode($res));
    }
    else {
        $res = array(   
            'code' => 0,
            'message' => 'Insert question success',
            'question' => $question,
            'id' => $id
        );

        die(json_encode($res));
    }
?>