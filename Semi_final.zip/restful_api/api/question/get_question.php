<?php

    if(!isset($_GET['id'])) {
        $res = array(
            'code' => 1,
            'message' => 'Invalid parameters'
        );
    }
    else {
        $id = $_GET['id'];

        header('Content-Type: application/json');

        require_once('../../config_model/question_db.php');
    
        $question = get_question($id);
    
        $res = array(
            'code' => 0,
            'message' => 'Load question success',
            'question' => $question
        );
    }

    echo json_encode($res);
?>