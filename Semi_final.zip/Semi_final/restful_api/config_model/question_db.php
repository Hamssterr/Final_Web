<?php
    require_once('db.php');

    // read full data
    function get_questions() {
        $conn = get_connection();
        $sql = "select * from question";

        $pointer = $conn->query($sql);

        $items = [];

        for($i = 1; $i <= $pointer->num_rows; $i ++) {
            $items[] = $pointer->fetch_assoc();
        }

        return $items;
    }

    // read 1 data
    function get_question($id) {
        $conn = get_connection();
        $sql = "select * from question where id_question = ?";

        $stm = $conn->prepare($sql);
        $stm->bind_param('i', $id);

        $stm->execute();

        $result = $stm->get_result();

        $item = $result->fetch_assoc();

        return $item;
    }

    //create data
    function add_question($title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true)
    {
        $conn = get_connection();
        $sql = "insert into question(title, sentence_a, sentence_b, sentence_c, sentence_d, sentence_true) values(?,?,?,?,?,?)";

        $stm = $conn->prepare($sql);
        $stm->bind_param('ssssss', $title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true);

        if(!$stm->execute()) {
            return null;
        }

        $sql = "select * from question where title = '$title'";
        $pointer = $conn->query($sql);
        $row = $pointer->fetch_assoc();
        $id = $row['id_question'];

        return $id;
    }

    //update data
    function update_question($id, $title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true)
    {
        $conn = get_connection();
        $sql = "update question set title = ?, 
        sentence_a = ?, sentence_b = ?, sentence_c = ?, sentence_d = ?, sentence_true = ? where id_question = ?";

        $stm = $conn->prepare($sql);
        $stm->bind_param('ssssssi', $title, $sentence_a, $sentence_b, $sentence_c, $sentence_d, $sentence_true, $id);

        $stm->execute();

        return $stm->affected_rows === 1;
    }

    //delete data
    function delete_question($id)
    {
        $conn = get_connection();
        $sql = "delete from question where id_question = ?";

        $stm = $conn->prepare($sql);
        $stm->bind_param('i', $id);

        $stm->execute();

        return $stm->affected_rows === 1;
    }
?>