let current_question = 0;
let point = 0;
let answer_true = null;
let total_question = 0;

const quiz = document.getElementById('question');
const title = document.getElementById('title');
const answer = document.querySelectorAll('.answer');
const a_answer = document.getElementById('a_answer');
const b_answer = document.getElementById('b_answer');
const c_answer = document.getElementById('c_answer');
const d_answer = document.getElementById('d_answer');
const submitBtn = document.getElementById('submit');

submitBtn.addEventListener("click", () => {
    current_question++;

    if(get_answer() === answer_true) {
        point++;
    }

    if(current_question < total_question) {
        load_question();
    }
    else {
        quiz.innerHTML = `
            <h2>You answered ${point}/${total_question} questions correctly</h2>
            <button onclick="location.reload()">Do again</button>
        `
    }
})

function load_question() {
    fetch('http://localhost/restful_api/api/question/get_questions.php')
    .then(res => res.json())
    .then(data => {

        total_question = data.question.length;

        removeChecked();

        const get_question = data.question[current_question];
        
        title.innerText = get_question.title;
        a_answer.innerText = get_question.sentence_a;
        b_answer.innerText = get_question.sentence_b;
        c_answer.innerText = get_question.sentence_c;
        d_answer.innerText = get_question.sentence_d;

        answer_true = get_question.sentence_true;
    })
    .catch(error => console.log(error));
}

function removeChecked() {
    answer.forEach((answer) => {
        answer.checked = false;
    })
}

function get_answer() {
    let res = undefined;

    answer.forEach((answer) => {
        if(answer.checked) {
            res = answer.id;
        }
    })

    return res;
}

load_question();