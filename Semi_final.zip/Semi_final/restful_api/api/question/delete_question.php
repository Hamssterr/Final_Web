<?php

    header('Content-Type: application/json');

    require_once('../../config_model/question_db.php');

    if($_SERVER['REQUEST_METHOD'] != 'DELETE') {
        $res = array(
            'code' => 4,
            'message' => 'This API only supports DELETE'
        );

        http_response_code(405);

        die(json_encode($res));
    }

    if(!isset($_GET['id'])) {
        $res = array(
            'code' => 1,
            'message' => 'Missing question id'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    $id = $_GET['id'];

    $id = intval($id);

    if($id === 0) {
        $res = array(
            'code' => 1,
            'message' => 'Invalid question id'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    if($id < 1 || $id > 1000) {
        $res = array(
            'code' => 1,
            'message' => 'Question id is out of range'
        );

        http_response_code(400);

        die(json_encode($res));
    }

    $result = delete_question($id);

    if(!$result) {
        $res = array(
            'code' => 3,
            'message' => 'Question id does not exist'
        );

        die(json_encode($res));
    }
    else {
        $res = array(   
            'code' => 0,
            'message' => 'Delete question success',
            'id' => $id
        );

        die(json_encode($res));
    }
?>