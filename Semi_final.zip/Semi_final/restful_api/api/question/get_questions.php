<?php
    header('Content-Type: application/json');

    require_once('../../config_model/question_db.php');

    $questions = get_questions();

    $res = array(
        'code' => 0,
        'message' => 'Load questions success',
        'question' => $questions
    );

    echo json_encode($res);

?>