-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2023 at 03:12 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id_question` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sentence_a` varchar(255) NOT NULL,
  `sentence_b` varchar(255) NOT NULL,
  `sentence_c` varchar(255) NOT NULL,
  `sentence_d` varchar(255) NOT NULL,
  `sentence_true` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id_question`, `title`, `sentence_a`, `sentence_b`, `sentence_c`, `sentence_d`, `sentence_true`) VALUES
(1, 'Trong NameNode, lượng bộ nhớ cần thiết là', 'Tương tự như của node chính', 'Phải có ít nhất một nửa node chính', 'Phải gấp đôi node chính', 'Chỉ phụ thuôc vào số lượng node dữ liệu mà nó sẽ xử lý', 'sentence_a'),
(2, 'Khi một node dự phòng được sử dụng trong một cụm thì không cần', 'Node kiểm tra (Check point node)', 'Node tên phụ (Secondary name node)', 'Data Node phụ (Secondary data node)', 'Nhận thức về giá đỡ (Rack awareness)', 'sentence_c'),
(3, 'Nhận thức về giá đỡ trong NameNode có nghĩa là', 'Nó có bao nhiêu giá đỡ có sẵn trong cụm', 'Nó nhận thức được ánh xạ giữa nút và giá đỡ', 'Nó nhận biết được số lượng nút trong mỗi rack', 'Nó biết những DataNode nào không có sẵn trong cụm', 'sentence_a'),
(4, 'Khi một máy được khai báo là datanode, dung lượng ở đĩa trong đó', 'Chỉ có thể được sử dụng cho lưu trữ HDFS', 'Có thể được sử dụng cho cả lưu trữ HDFS và không phải HDFS', 'Không thể truy cập bằng các lệnh không phải hadoop', 'Không thể lưu trữ các tệp văn bản', 'sentence_b'),
(5, 'Mục đích của nút checkponint trong cụm hadoop là', 'Kiểm tra xem NameNode có hoạt động không', 'Kiểm tra xem tệp hình ảnh có đồng bộ giữa NodeName và NameNode phụ hay không', 'Hợp nhất hình ảnh và chỉnh sửa nhật ký và tải nó trở lại NameNode đang hoạt động', 'Kiểm tra xem các DataNode nào không thể truy cập được', 'sentence_b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id_question`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id_question` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
