Chèn thư mục database.sql vào phpmyadmin
Dán trực tiếp mã nguồn trong thư mục code vào thư mục htdocs