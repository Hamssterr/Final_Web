<?php
    require_once('../config_model/music_db.php');

    reset_listened();
?>